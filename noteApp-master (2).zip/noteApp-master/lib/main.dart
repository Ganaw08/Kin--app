import 'package:flutter/material.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:test1/ui/pages/add_player_page.dart';
import './ui/pages/categories_screen.dart';
import './ui/pages/chose_type_first.dart';
import './ui/pages/player_profile.dart';
import './/ui/pages/password_page.dart';
import './ui/pages/quiz_page.dart';
import './ui/pages/categories_players_screen.dart';
void main() => runApp(Myapp());
class Myapp extends StatefulWidget {

  @override
  State<Myapp> createState() => _MyappState();
}

class _MyappState extends State<Myapp> {

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'new App',
      theme: ThemeData(
          colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.blue).copyWith(secondary: Colors.blueAccent),
          canvasColor: Colors.white,
          textTheme:ThemeData.light().textTheme.copyWith(
            titleMedium: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          )
      ),
      // home:CategoriesScreen(),
     routes: {
        '/':(context)=>ChoseTypeFirst(),
        playersScreen.routeName:(context)=>playersScreen(),
        Player_Profile.routeName:(context)=>Player_Profile(),


     },
    );

  }
}


class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      ),
      body: null,
    );
  }
}
