import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:test1/ui/pages/password_page.dart';
import '../../size_config.dart';
import '../pages/categories_players_screen.dart';


class CategoryItem extends StatelessWidget {
  final String id;
  final String title;

  CategoryItem(this.id, this.title);
 // void SelectCategory(BuildContext ctx){
   // Navigator.of(ctx).pushNamed(playersScreen.routeName,
      //    arguments: {
      //       'id': id,
      //       'title' : title,
      //     }
//);
  //}

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return SafeArea(
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 50),
        width: double.infinity,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical:10),
          child: ElevatedButton(
    onPressed: (){Get.to(PasswordPage());},
    child: Text(
    title,
    style: const TextStyle(fontSize: 25),
    ),
    style: ElevatedButton.styleFrom( // returns ButtonStyle
    foregroundColor: Colors.white, backgroundColor: Color(0xFF7DB9B9),
    shape:  StadiumBorder (
    side: BorderSide( width: 5, color: Color(0xFF7DB9B9)) // Not Working (Read Note).
    ),
        ),
      ),
    ),
      ),
    );
  }
}
