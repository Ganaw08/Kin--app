import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:image_picker/image_picker.dart';
class BuildImagePiker extends StatefulWidget {
  const BuildImagePiker({Key? key}) : super(key: key);

  @override
  State<BuildImagePiker> createState() => _BuildImagePikerState();
}

class _BuildImagePikerState extends State<BuildImagePiker> {
  @override
  Widget build(BuildContext ctx) {
    File? _selectedImage;
    Future getImage(ImageSource src) async {
      final XFile? pickedFile = await ImagePicker().pickImage(source: src);
      if (pickedFile != null) {
        print('Image selected');
        setState(() {
          _selectedImage = File(pickedFile.path);
        });
        return _selectedImage;
      }
      else {
        print('No image selected.');
      }
    }

    Builder buildDialogItem(
        BuildContext context, String text, IconData icon, ImageSource src) {
      return Builder(
        builder: (innerContext) => Container(
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor,
            borderRadius: BorderRadius.circular(15),
          ),
          child: ListTile(
            leading: Icon(icon, color: Colors.white),
            title: Text(text),
            onTap: () async {
              getImage(src);
              Navigator.of(innerContext).pop();
            },
          ),
        ),
      );
    }

    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
     SizedBox(
              height: 115,
              width: 115,
              child: Stack(
                fit: StackFit.expand,
                clipBehavior: Clip.none,
                children: [
                  CircleAvatar(
                    backgroundImage: NetworkImage(
                        'https://fcb-abj-pre.s3.amazonaws.com/img/jugadors/MESSI.jpg'),
                  ),
                  Positioned(
                    right: -16,
                    bottom: 0,
                    child: SizedBox(
                      height: 46,
                      width: 46,
                      child: TextButton(
                        style: TextButton.styleFrom(
                          foregroundColor: Colors.white, shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(50),
                            side: BorderSide(color: Colors.white),
                          ),
                          backgroundColor: Color(0xFFF5F6F9),
                        ),
                        onPressed: () {
                          var ad = AlertDialog(
                            title: const Text('Choose Picture from:'),
                            content: SizedBox(
                              height: 150,
                              child: Column(
                                children: [
                                  const Divider(color: Colors.black),
                                  buildDialogItem(ctx, 'Camera', Icons.add_a_photo_outlined,
                                      ImageSource.camera),
                                  const SizedBox(height: 10),
                                  buildDialogItem(ctx, 'Gallery', Icons.image_outlined,
                                      ImageSource.gallery),
                                ],
                              ),
                            ),
                          );
                          showDialog(
                              context: ctx,
                              builder: (BuildContext context) {
                                return ad;
                              });
                        },
                        child: SvgPicture.asset("assets/icons/Camera Icon.svg"),
                      ),
                    ),
                  )
                ],
              ),
            ),

            //CircleAvatar(
              //radius: MediaQuery.of(context).size.width*0.15,
              //backgroundImage: _selectedImage==null?null:FileImage(_selectedImage!),

            //),

        _selectedImage == null ? const Center() : Image.file(_selectedImage!),
      ],
    );

  }
}
