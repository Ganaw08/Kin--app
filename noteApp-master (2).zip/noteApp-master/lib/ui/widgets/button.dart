import 'package:flutter/material.dart';

import '../../size_config.dart';



class MyButton extends StatelessWidget {
 MyButton( {required this.label, required this.onTap});
final String label ;
final  Function() onTap;


  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        alignment: Alignment.center,
        width: 119 ,
        height: 55,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          color: Color(0xFF6AA7AA),
        ),
        child: Text(label,style: const TextStyle(color: Colors.white,),textAlign: TextAlign.center,),
      ),
    );
  }
}
