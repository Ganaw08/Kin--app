
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../pages/State.dart';
import '../pages/result_quiz.dart';


class MainDrawer extends StatelessWidget {
  Widget buildListeTitle(String title ,IconData icon,Function()? tapHandlar ){
    return ListTile(
      leading: Icon(
        icon,
        size: 28,
        color: Colors.white60,
      ),
      title: Text(
          title,
          style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,color: Colors.white)
      ),
      onTap: tapHandlar,

    );
  }
  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor:Color(0xFF4AA3A2),
      child: Column(
        children: [
          Container(
            height: 120,
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            alignment: Alignment.centerLeft,
            color: Color(0xFF3C8F95),
            child: const Text(
              'kine app',
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  color: Colors.white),
            ),
          ),
          SizedBox(height: 8),
          buildListeTitle("State",Icons.medical_information,(){Get.to(State_Page());}),
          buildListeTitle("medical history",Icons.history,(){}),
          buildListeTitle("Quiz ",Icons.quiz,(){Get.to(Result_Quiz());}),
          buildListeTitle("Data analysis ",Icons.analytics,(){}),

        ],
      ),
    );
  }
}
