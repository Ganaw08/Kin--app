import 'package:flutter/material.dart';

import '../../size_config.dart';
import '../pages/player_profile.dart';


  //void SelectPlayer(BuildContext ctx ) {
 //   Navigator.of(ctx).pushNamed(Player_Profile.routeName,arguments:id).then((result){
      //  if (result!=null)removeItem(result);
    //}
//    );


  //}
class PlayerItem extends StatelessWidget {
  final String ImageUrl;
  final String id;
  final String title;
  final String height;
  final String weight;


  const PlayerItem({required this.ImageUrl,
    required this.title,
    required this.id,
    required this.height,
    required this.weight,

  });

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return InkWell(
      onTap: () {
        Navigator.of(context).pushNamed(Player_Profile.routeName);
      },
      child: Card(
        color: Color(0xFF3C8F95),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
        elevation: 4,
        margin: EdgeInsets.all(10),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              CircleAvatar(
                radius: 45,
                backgroundImage: NetworkImage(
                    'https://fcb-abj-pre.s3.amazonaws.com/img/jugadors/MESSI.jpg'),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text('Leo Messi',
                        style: TextStyle(fontSize: 28, color: Colors.white)),
                    SizedBox(height: 8,),
                    Text('1.55 m ',
                        style: TextStyle(fontSize: 18, color: Colors.white)),
                    Text('60 kg ',
                        style: TextStyle(fontSize: 18, color: Colors.white)),
                  ],
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}
