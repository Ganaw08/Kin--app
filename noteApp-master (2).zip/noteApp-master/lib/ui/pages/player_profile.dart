import 'package:flutter/material.dart';

import '../../theme.dart';
import '../widgets/image_picker.dart';
import '../widgets/profile_drawer.dart';
class Player_Profile extends StatefulWidget {
  const Player_Profile({Key? key}) : super(key: key);
  static const routeName ='Player_Profile';

  @override
  State<Player_Profile> createState() => _Player_ProfileState();
}

class _Player_ProfileState extends State<Player_Profile> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          appBar:AppBar(
            backgroundColor: Color(0xFF3C8F95),
            title: Text('Profile'),
            actions: [IconButton(onPressed: (){}, icon:Icon(Icons.edit))],
          ),
          drawer: MainDrawer(),
          backgroundColor: const Color(0xFF347672),
          body: Padding(
            padding: const EdgeInsets.only(left: 20,top:20,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                BuildImagePiker(),
                const SizedBox(height: 25,),
                playerinfo('FirstName','Leo'),
                const SizedBox(height: 10,),
                playerinfo('Lastname','Messi'),
                const SizedBox(height: 10,),
                playerinfo('Height','1.55 m' ),
                const SizedBox(height: 10,),
                playerinfo('Weight','60 kg' ),
                const SizedBox(height: 10,),
                playerinfo('Date of birdhday','22/22/2022' ),
                const SizedBox(height: 10,),
                playerinfo('Email', 'messimessi@gmail.com'),
                const SizedBox(height: 10,),
                playerinfo('Number', '+002522155245'),
                const SizedBox(height: 10,),
              ],
            ),
          ),

        ));
  }
  playerinfo(String title, String information ){
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,style:headingStyle ),
          SizedBox(height: 10,),
          Text(information,style: subTitleStyle,),
        ],
      ) ,
    );
  }
}
