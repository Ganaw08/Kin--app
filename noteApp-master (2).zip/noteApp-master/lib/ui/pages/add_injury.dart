import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../size_config.dart';
import '../../theme.dart';
import '../widgets/input_field.dart';



class Add_Injury extends StatefulWidget {


  @override
  State<Add_Injury> createState() => _Add_InjuryState();
}

class _Add_InjuryState extends State<Add_Injury> {
  final List<String> injurytype = [
    'Item1',
    'Item2',
    'Item3',
    'Item4',
    'Item5',
    'Item6',
    'Item7',
    'Item8',
  ];
  String? dropdownValue2;
  DateTime _selectedDateDebut = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0xFF3C8F95),
        body: Container(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.all(SizeConfig.screenHeight * 0),
                  child: Image.asset("assets/images/topContainer.png",),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 20,left: 20),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        DecoratedBox(
                          decoration: BoxDecoration(
                              color: Color(0xFF347672),
                              //background color of dropdown button
                              border: Border.all(color: Colors.black38, width: 3),
                              //border of dropdown button
                              borderRadius: BorderRadius.circular(50),
                              //border raiuds of dropdown button
                              boxShadow: const <BoxShadow>[
                                //apply shadow on Dropdown button
                                BoxShadow(
                                    color: Color.fromRGBO(0, 0, 0, 0.57),
                                    //shadow for button
                                    blurRadius: 5) //blur radius of shadow
                              ]),
                          child: Padding(
                            padding: EdgeInsets.only(left: 10, right: 10),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<String>(
                                value: dropdownValue2,
                                isExpanded: true,
                                hint: Row(
                                  children: const [
                                    Icon(
                                      Icons.list,
                                      size: 28,
                                      color: Colors.white,
                                    ),
                                    SizedBox(
                                      width: 4,
                                    ),
                                    Expanded(
                                      child: Text(
                                        'Select Your Name',
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                                items: injurytype.map((String items) {
                                  return DropdownMenuItem(
                                    value: items,
                                    child: Text(items),
                                  );
                                }).toList(),
                                onChanged: (String? value) {
// This is called when the user selects an item.
                                  setState(() {
                                    dropdownValue2 = value!;
                                  });
                                },
                                icon: const Icon(
                                  Icons.arrow_downward_outlined,
                                ),
                                iconSize: 22,
                                iconEnabledColor: Colors.white,
                                iconDisabledColor: Colors.white,
                                dropdownColor: Color(0xFF6AA7AA),
                                elevation: 15,
                                style: const TextStyle(color: Colors.white),
                                underline: Container(
                                  height: 5,
                                  color: Color(0xFF6AA7AA),
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 20,),
                        Text('Description :',
                           style: titleheadingStyle,),
                        SizedBox(height: 20,),
                        TextFormField(
                          maxLines: 5,
                          keyboardType: TextInputType.multiline,
                          decoration: InputDecoration(
                              hintText: 'Enter your description here ',
                              hintStyle: TextStyle(
                                  color: Colors.grey
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.all(Radius.circular(10)),

                              ),


      ),
                        ),
                        SizedBox(height: 20,),
                      ],
                    ),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 16),
                  child: InputField(
                    title: 'DateDebut',
                    hint: DateFormat.yMd().format(_selectedDateDebut),
                    widget: IconButton(
                        onPressed: () => getDataFromUser(),
                        icon: const Icon(Icons.calendar_today_outlined,
                            color: Colors.grey)),
                  ),
                ),


              ],
            ),
          ),
        ),
      ),
    );
  }
  getDataFromUser() async{
    DateTime? pickDate = await showDatePicker(context: context,
        initialDate: _selectedDateDebut,
        firstDate: DateTime(2015),
        lastDate: DateTime(2030));
    if (pickDate != null)
      setState(() => _selectedDateDebut = pickDate);

    else{
      print('its null or something is wrrong ');
    }

  }
}
