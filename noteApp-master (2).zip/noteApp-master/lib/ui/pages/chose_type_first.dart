import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../size_config.dart';
import '../pages/quiz_page.dart';

import '../widgets/button.dart';
import 'categories_screen.dart';

class ChoseTypeFirst extends StatefulWidget {
  const ChoseTypeFirst({Key? key}) : super(key: key);

  @override
  State<ChoseTypeFirst> createState() => _ChoseTypeFirstState();
}

class _ChoseTypeFirstState extends State<ChoseTypeFirst> {
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return SafeArea(
      child: Scaffold(
        body: Column(
            children: [
              Container(
                padding:EdgeInsets.only(top:SizeConfig.screenHeight*0),
                child:Image.asset("assets/images/topContainer2.png",),
              ),
              Padding(
                padding: const EdgeInsets.all(50.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Image.asset("assets/images/splachScreenimage.png",height: 110,),
                      SizedBox(height: 25,),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          MyButton(
                              onTap: () {
                                Get.to(CategoriesScreen());                      },
                              label: 'Kine Team'),
                          SizedBox(height: 18),

                          MyButton(
                              onTap: () {
                                Get.to(QuizPage());
                              },
                              label: 'Player Team')
                        ],
                      ),
                    ],
                  ),
              ),

              Container(
                padding:EdgeInsets.only(top:SizeConfig.screenHeight*0.26),
                child:Image.asset("assets/images/botcontainer.png",),
              ),
            ],
          ),
        ),
    );
  }
}
