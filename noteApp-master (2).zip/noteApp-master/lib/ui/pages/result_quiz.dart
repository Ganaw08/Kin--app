import 'package:flutter/material.dart';

class Result_Quiz extends StatefulWidget {
  @override
  State<Result_Quiz> createState() => _Result_QuizState();
}

class _Result_QuizState extends State<Result_Quiz> {
  @override
  Widget build(BuildContext context) {
    return   SafeArea(
      child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(title:Text('title'),backgroundColor: Color(0xFF347672),),
          body:ListView.builder(
            itemBuilder:(ctx,index){
              return buildListWheel();
            },
            itemCount:10 ,
          ),

      ),
    );
  }

  Widget buildListWheel() {
    return Card(
      color: Color(0xFF3C8F95),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
      elevation: 20,
      margin: EdgeInsets.all(25),
          child  : Column(
            children: [
              Text( ' Quality score =  5',
                  style: TextStyle(fontSize: 18, color: Colors.white)),
              Text( 'Stresse Score = 7',
                  style: TextStyle(fontSize: 18, color: Colors.white)),
              Text(' Fatigue Score = 8',
                  style: TextStyle(fontSize: 18, color: Colors.white)),
            ],
          ),
    );
  }
}