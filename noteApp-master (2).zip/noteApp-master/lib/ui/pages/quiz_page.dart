import 'package:flutter/material.dart';
import '../../size_config.dart';
import '../widgets/button.dart';


class QuizPage extends StatefulWidget {

  @override
  State<QuizPage> createState() => _QuizPageState();
}
class _QuizPageState extends State<QuizPage> {
  final List<String> items = [
    'Item1',
    'Item2',
    'Item3',
    'Item4',
    'Item5',
    'Item6',
    'Item7',
    'Item8',
  ];
  double _currentSliderValueQuality = 1;
  double _currentSliderValueStress = 1;
  double _currentSliderValueFatigue = 1;

  String? dropdownValue;
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: const Text('Quiz Time', textAlign: TextAlign.center),
          backgroundColor: Color(0xFF347672),
        ),
        body: SingleChildScrollView(
          child: Center(
            child: Column(
              children: <Widget>[
                SizedBox(height: SizeConfig.screenHeight*0.01,),
                DecoratedBox(
                  decoration: BoxDecoration(
                      color: Color(0xFF347672),
                      //background color of dropdown button
                      border: Border.all(color: Colors.black38, width: 3),
                      //border of dropdown button
                      borderRadius: BorderRadius.circular(50),
                      //border raiuds of dropdown button
                      boxShadow: const <BoxShadow>[
                        //apply shadow on Dropdown button
                        BoxShadow(
                            color: Color.fromRGBO(0, 0, 0, 0.57),
                            //shadow for button
                            blurRadius: 5) //blur radius of shadow
                      ]),
                  child: Padding(
                    padding: EdgeInsets.only(left: 30, right: 30),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: dropdownValue,
                        isExpanded: true,
                        hint: Row(
                          children: const [
                            Icon(
                              Icons.list,
                              size: 28,
                              color: Colors.white,
                            ),
                            SizedBox(
                              width: 4,
                            ),
                            Expanded(
                              child: Text(
                                'Select Your Name',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                        items: items.map((String items) {
                          return DropdownMenuItem(
                            value: items,
                            child: Text(items),
                          );
                        }).toList(),
                        onChanged: (String? value) {
// This is called when the user selects an item.
                          setState(() {
                            dropdownValue = value!;
                          });
                        },
                        icon: const Icon(
                          Icons.arrow_downward_outlined,
                        ),
                        iconSize: 22,
                        iconEnabledColor: Colors.white,
                        iconDisabledColor: Colors.white,
                        dropdownColor: Color(0xFF6AA7AA),
                        elevation: 15,
                        style: const TextStyle(color: Colors.white),
                        underline: Container(
                          height: 5,
                          color: Color(0xFF6AA7AA),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: SizeConfig.screenHeight*0.02,),
                Image.asset("assets/images/quiz1.jpg"),
              Slider(
                value: _currentSliderValueQuality,
                max: 7,
                divisions: 7,
                label: _currentSliderValueQuality.round().toString(),
                onChanged: (double value) {
                  setState(() {
                    _currentSliderValueQuality = value;
                  });
                },
              ),
                SizedBox(height: SizeConfig.screenHeight*0.02,),
                Image.asset("assets/images/quiz2.jpg"),
                Slider(
                  value: _currentSliderValueStress,
                  max: 7,
                  divisions: 7,
                  label: _currentSliderValueStress.round().toString(),
                  onChanged: (double value) {
                    setState(() {
                      _currentSliderValueStress = value;
                    });
                  },
                ),
                SizedBox(height: SizeConfig.screenHeight*0.02,),
                Image.asset("assets/images/quiz3.jpg"),
                Slider(
                  value: _currentSliderValueFatigue,
                  max: 7,
                  divisions: 7,
                  label: _currentSliderValueFatigue.round().toString(),
                  onChanged: (double value) {
                    setState(() {
                      _currentSliderValueFatigue = value;
                    });
                  },
                ),
                MyButton(onTap: () { }, label: 'Send',),

              ],
            ),

          ),
        ),
      ),
    );
  }
}
