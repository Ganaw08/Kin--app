

import 'package:get/get.dart';

import '../widgets/player_item.dart';
import 'package:flutter/material.dart';
import 'add_player_page.dart';
class playersScreen extends StatefulWidget {
  static const routeName ='players_Screen';
  @override
  State<playersScreen> createState() => _playersScreenState();

}

class _playersScreenState extends State<playersScreen> {

  @override
  Widget build(BuildContext context) {

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(title:Text('title'),backgroundColor: Color(0xFF347672),),
        body:ListView.builder(
          itemBuilder:(ctx,index){
            return PlayerItem(
              id: 'id',
              ImageUrl:'urlimage',
              title: 'title',
              height: 'height',
              weight: 'weight',
            );
  },
          itemCount:20 ,
        ),
          floatingActionButton: FloatingActionButton(
            backgroundColor: Color(0xFF3C8F95),
            onPressed: () {
              Get.to(AddPlayerPage());
            },
            child: Icon(Icons.add),
          ),
      ),
    );
  }

}
