import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:test1/ui/pages/add_injury.dart';

import '../../size_config.dart';

class State_Page extends StatelessWidget {
  Widget buildSectionTitle(BuildContext context, String text) {
    return Scaffold(
      body: Container(
        margin: EdgeInsets.symmetric(vertical: 10),
        child: Text(
          text,
          style: Theme.of(context).textTheme.titleMedium,
        ),
      ),
    );
  }
  Widget buildContainer(Widget Child) {
    return Container(
      decoration: BoxDecoration(
        color: Color(0xFF3C8F95),
        borderRadius: BorderRadius.circular(20),
      ),
      margin: EdgeInsets.all(10),
      padding: EdgeInsets.all(10),
      height: SizeConfig.screenHeight*0.65,
      width: SizeConfig.screenWidth,
      child: Child,
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor:  Color(0xFF3C8F95),
        body: Container(
          child: Column(
            children: [
              Container(
                padding:EdgeInsets.only(top:SizeConfig.screenHeight*0),
                child:Image.asset("assets/images/topContainer.png",),
              ),
              buildContainer(
                ListView.builder(
                  itemBuilder: (ctx, index) => InkWell(
                    onTap: (){},
                    child: Card(
                        color: Colors.white,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 30, vertical: 30),
                          child:
                          Row(
                            children: [
                              CircleAvatar(
                                child: Text("${index+1}"),
                              ),
                              SizedBox(width: 30,),
                              Text(
                               'Injury',
                                  style: TextStyle(fontSize: 28, color: Colors.black)
                              ),
                            ],
                          ),
                        )),
                  ),
                  itemCount: 10,
                ),
              ),
              Stack(
                alignment: Alignment.bottomLeft,
                children:[ Container(
                  padding:EdgeInsets.only(top:SizeConfig.screenHeight*0.057798),
                  child:Image.asset("assets/images/botcontainer2.png",),
                ),Positioned(child:
                Image.asset("assets/images/State.png",alignment: Alignment.bottomLeft,height: 130,), ),
                ]
              ),
            ],
          ),
        ),
        floatingActionButton: FloatingActionButton(
          elevation: 20,
          backgroundColor: Color(0xFF3C8F95),
          onPressed: () {
            Get.to(Add_Injury());
          },
          child: Icon(Icons.add),
        ),
      ),
    );
  }
}
