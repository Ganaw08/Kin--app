import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';


class MedicalHistory extends StatefulWidget {
    static const routeName ='medical_history';
    final List<PlatformFile> files ;
    final ValueChanged<PlatformFile> onOpenedFile;
MedicalHistory({required this.files,required this.onOpenedFile});

  @override
  State<MedicalHistory> createState() => _MedicalHistoryState();
}

class _MedicalHistoryState extends State<MedicalHistory> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(child:
    Scaffold(
      appBar: AppBar(),
        body: Center(
           child: GridView.builder(
               gridDelegate:
           const SliverGridDelegateWithFixedCrossAxisCount
             (crossAxisCount:2,
               mainAxisSpacing: 8,
               crossAxisSpacing: 8 ),
               itemCount: widget.files.length,
               itemBuilder: (context,index){
                 final file=widget.files[index];
                 return buildFile(file);
           }),
        ),


        floatingActionButton:FloatingActionButton(
          backgroundColor: Colors.green,
          onPressed: ()
          async{
          final result=   await FilePicker.platform.pickFiles(allowMultiple: true);
          if (result ==null )return;

          openFiles(result.files);

          final file =result.files.first;
          openFile(file);


         final newFile= await saveFilePermantly(file);

          },
          child: Icon(Icons.add),
        )

    )
    );
  }



 Future<File> saveFilePermantly(PlatformFile file) async {
    final appStorage=await getApplicationDocumentsDirectory();
    final newFile=File('${appStorage.path}/${file.name}');
    return File(file.path!).copy(newFile.path);


  }

  void openFile(PlatformFile file) {
    OpenFile.open(file.path!);
  }

  MedicalHistory openFiles(List<PlatformFile> files) {
    return MedicalHistory(files: files, onOpenedFile: openFile);

  }

  Widget buildFile(PlatformFile file) {
    final extension=file.extension??'none';
    return InkWell(
      onTap:()=>widget.onOpenedFile(file),
      child:Container(
        padding: EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child:
            Container(
              alignment: Alignment.center,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                '.$extension',
                style: TextStyle(fontWeight: FontWeight.bold,fontSize: 28,color: Colors.white),
              ),
            )
            ),
           SizedBox(height:8),
            Text(file.name,style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),overflow:TextOverflow.ellipsis,)
          ],
        ),
      ) ,
    );
  }
  }
