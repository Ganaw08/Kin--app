import '../../size_config.dart';
import '../widgets/category_item.dart';
import 'package:flutter/material.dart';


class CategoriesScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xFF347672),
       body:
        SingleChildScrollView(
          child: Column(
            children: [
              Container(
                padding:EdgeInsets.only(top:SizeConfig.screenHeight*0),
                child:Image.asset("assets/images/topContainer.png",),
              ),
              Column(
               mainAxisAlignment: MainAxisAlignment.center,
               crossAxisAlignment: CrossAxisAlignment.center,
               children: [
                 Image.asset("assets/images/Category.png",height:150,),
                 SizedBox(height: 25),
                 Column(
                   mainAxisAlignment: MainAxisAlignment.center,
                   crossAxisAlignment: CrossAxisAlignment.center,
                   children: [
                     CategoryItem('id', 'U21',),
                     CategoryItem('id', 'U20',),
                     CategoryItem('id', 'U19',),
                     CategoryItem('id', 'U18',),
                   ],

                      ),

               ],
       ),
              Container(
                padding:EdgeInsets.only(top:SizeConfig.screenHeight*0.06919),
                child:Image.asset("assets/images/botcontainer2.png",),
              ),
            ],
          ),
        ),
    ),
         );
  }
}
