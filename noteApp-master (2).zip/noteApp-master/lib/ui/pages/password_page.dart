import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../size_config.dart';
import '../../theme.dart';
import '../widgets/button.dart';
import 'categories_players_screen.dart';

class PasswordPage extends StatefulWidget {
  static const routeName ='PasswordPage';

  @override
  State<PasswordPage> createState() => _PasswordPageState();
}

class _PasswordPageState extends State<PasswordPage> {
  final TextEditingController Password = TextEditingController();
  bool _isObscure = true;

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return SafeArea(
      child: Scaffold(
        backgroundColor:Color(0xFF347672) ,
        body:  SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  padding:EdgeInsets.all(SizeConfig.screenHeight*0),
                  child:Image.asset("assets/images/topContainer.png",),
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(height:SizeConfig.screenHeight*0.08 ),
                    Image.asset("assets/images/pasword.png",height:  SizeConfig.screenHeight*0.18,),
                Container(
                  width: SizeConfig.screenWidth*0.8,
                  height: SizeConfig.screenHeight*0.06,
                  padding: const EdgeInsets.only(left: 18),
                  margin: const EdgeInsets.only(top: 8),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.white)),
                  child: Row(
                    children: [
                    Expanded(
         child: TextField(
                  obscureText: _isObscure,
                  controller: Password,
                  cursorColor: Colors.white,
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                      hintText: 'Enter Your Password',
                      hintStyle: subTitleStyle,
                      labelStyle:TextStyle(color: Colors.white),
                      enabledBorder: UnderlineInputBorder(borderSide:BorderSide(color:Colors.white)),
                      focusedBorder: UnderlineInputBorder(borderSide:BorderSide(color:Colors.white ,width: 0)),
                      // this button is used to toggle the password visibility
                      suffixIcon: IconButton(
                        color: Colors.white,
                          icon: Icon(
                              _isObscure ? Icons.visibility : Icons.visibility_off),
                          onPressed: () {
                            setState(() {
                              _isObscure = !_isObscure;
                            });
                          })),
      ),
                )

  ]    ),
      ),
                    SizedBox(height: SizeConfig.screenHeight*0.04,),
                    MyButton(label: 'Send', onTap: () { Get.to(playersScreen());},)
                  ],
                ),

                Container(
                  padding:EdgeInsets.only(top:SizeConfig.screenHeight*0.26),
                  child:Image.asset("assets/images/botcontainer2.png",),
                ),
              ],
            ),
          ),
        ),

    );
  }
}
