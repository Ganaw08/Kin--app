import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../theme.dart';
import '../widgets/button.dart';
import '../widgets/image_picker.dart';
import '../widgets/input_field.dart';

class AddPlayerPage extends StatefulWidget {
  static const routeName ='AddplayerPage';

  @override
  State<AddPlayerPage> createState() => _AddPlayerPageState();
}
class _AddPlayerPageState extends State<AddPlayerPage> {
  final TextEditingController _Firstname = TextEditingController();
  final TextEditingController _LasteName = TextEditingController();

  final TextEditingController _email = TextEditingController();
  final TextEditingController _number = TextEditingController();
  final TextEditingController _height = TextEditingController();
  final TextEditingController _wheight= TextEditingController();



  DateTime _selectedDate = DateTime.now();


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0xFF347672),
        appBar: _AppBar( ),
        body: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: SingleChildScrollView(
            child: Column(
              children: [
                BuildImagePiker(),
                const SizedBox(height: 20,),
                Text(
                  'ADD Player',
                  style: headingStyle,
                ),
                const SizedBox(height: 20,),

                InputField(
                  title: 'First Name',
                  hint: 'Add First Name ',
                  controller: _Firstname,
                ),
                const SizedBox(height: 20,),

                InputField(
                  title: 'Last Name',
                  hint: ' Add Last  Name ',
                  controller: _LasteName,
                ),
                const SizedBox(height: 20,),

                InputField(
                  title: 'Email',
                  hint: 'Add the email  ',
                  controller: _email,
                ),
                const SizedBox(height: 20,),

                InputField(
                  title: 'Date',
                  hint: DateFormat.yMd().format(_selectedDate),
                  widget: IconButton(
                      onPressed: () =>getDataFromUser(),
                      icon: const Icon(Icons.calendar_today_outlined,
                          color: Colors.grey)),
                ),
                const SizedBox(height: 20,),
                Row(
                  children: [
                    Expanded(child:
                    InputField(
                      title: 'height',
                      hint: '1.70 m',
                      controller: _height,
                    ),
                    ),
                    const SizedBox(width: 20,),
                    Expanded(child:
                    InputField(
                      title: 'weight',
                      hint: '70 kg ',
                      controller: _wheight,
                    ),
                    ),
                  ],
                ),
                const SizedBox(height: 20,),
                InputField(
                  title: 'Number',
                  hint: 'Phone Number ',
                  controller: _number,
                ),
                const SizedBox(height: 20,),
                    const SizedBox(height: 20,),
                    MyButton(label: 'Creat Player',onTap: (){
                      _validateData();
                      },)
              ],
            ),
          ),
        ),
      ),
    );
  }
  AppBar _AppBar(){
    return AppBar(
      leading: IconButton(
          onPressed: (){Get.back();}, icon:  Icon(Icons.arrow_back_ios, color: Colors.white)),
      elevation: 0,
      backgroundColor: Color(0xFF3C8F95),

    );

  }
  _validateData(){
    if(_Firstname.text.isNotEmpty && _LasteName.text.isNotEmpty && _email.text.isEmpty ){
     //_addTaskDb();
      Get.back();
    }else if(_Firstname.text.isEmpty || _LasteName.text.isEmpty) {
      Get.snackbar('required', 'All files required',snackPosition: SnackPosition.BOTTOM,backgroundColor: Colors.white,colorText: pinkClr,
      icon: const Icon(Icons.warning_amber_rounded,color: Colors.red,));

    }else{
print('something is happing');
    }
  }
 //  _addTaskDb()async{
 // int value=  await _TaskController.addTask(task :Task(
 //      title: _titleController.text,
 //      note: _noteController.text,
 //      isCompleted: 0,
 //      date:DateFormat.yMd().format(_selectedDate),
 //      startTime: _startTime,
 //      endTime: _endTime,
 //      remind: _selectedRemind,
 //      repeat: _selecteRepeat
 //    ),
 //    );
 //  }
  getDataFromUser() async{
    DateTime? pickDate = await showDatePicker(context: context,
        initialDate: _selectedDate,
        firstDate: DateTime(2015),
        lastDate: DateTime(2030));
    if (pickDate != null)
      setState(() => _selectedDate = pickDate);

          else{
          print('its null or something is wrrong ');
          }

  }
  // getTimeFromUser({ required bool isStartTime}) async{
  //   TimeOfDay? pickTime = await showTimePicker(
  //     context: context,
  //     initialTime: isStartTime
  //         ? TimeOfDay.fromDateTime(DateTime.now())
  //         : TimeOfDay.fromDateTime(
  //             DateTime.now().add(const Duration(minutes: 15))),
  //   );
  //   String formattedfTime = pickTime!.format(context);
  //   if (isStartTime)
  //     setState(() => _startTime = formattedfTime);
  //   else if (!isStartTime)
  //     setState(() => _endTime = formattedfTime);
  //   else {
  //     print('time cancel or something is wrong ');
  //   }
  // }
}
